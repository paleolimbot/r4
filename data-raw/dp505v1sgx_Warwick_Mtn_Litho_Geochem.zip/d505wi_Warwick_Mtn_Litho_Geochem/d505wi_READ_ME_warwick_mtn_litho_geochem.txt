--------------------------------------------------------------
DP ME 505, Version 1, 2018. Lithogeochemical Data from the Warwick Mountain Area, 
Eastern Cobequid Highlands, Nova Scotia, 
by T.G. MacHattie and C.C. MacMullen.
--------------------------------------------------------------

For more Information and Updates on this digital product go to:

https://novascotia.ca/natr/meb/download/dp505.asp


Please read the licence.txt file.


---------------------------------------------------------
Metadata - Themes, Field Information, Abbreviations, Etc.
---------------------------------------------------------

.\metadata\d505wi_Metadata_Themes_Fields_Value_Keys.xls
.\metadata\dp505_v1.htm

--------------------------------------------
ArcGIS Users:
--------------------------------------------

This dataset was built in ArcGIS Desktop 10.2

MXD File Location: 
.\arcmap\project\d505wi_litho_geochemistry_102.mxd

File Geodatabase Location:
.\gdb\dd505wi_warwick_mtn_litho_geochem.gdb

Layer File Location
.\gdb

--------------------------------------------
ArcExplorer Users:
--------------------------------------------

NMF File Location: 
.\arcexpl\d505wi_warwick_mtn_litho_geochem.nmf

--------------------------------------------
SHP Files:
--------------------------------------------
.\shp

--------------------------------------------
XLS\CSV Files Users:
--------------------------------------------
.\xls



